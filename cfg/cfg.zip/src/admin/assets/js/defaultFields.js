let field = ['id', 'create_time', 'update_time', 'create_user', 'update_user'];


export default field;