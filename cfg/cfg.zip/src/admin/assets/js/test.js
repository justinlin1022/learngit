(function(window) {
let a = 1;
// console.log(`模板解析es6: ${a}`);
})(window);