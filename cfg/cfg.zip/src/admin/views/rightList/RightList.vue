<template>
  <div>权限列表</div>
</template>

<script>
  
</script>

<style>

</style>
